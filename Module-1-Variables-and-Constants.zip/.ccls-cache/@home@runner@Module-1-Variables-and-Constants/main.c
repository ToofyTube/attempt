#include <stdio.h>
#include <string.h>

int main(void) {
  char str []= "Lucinda Potter\n6/24/1992\nwork 000-000-0101\ncell 000-000-0189";
  printf("Unit Test #1 Expected Outcome\n %s\n\n", str);
  int info = "\nJohn Smith\n8/15/1978\nwork 000-111-0101\ncell 000-111-0189";
  printf("Unit Test #2 Expected Outcome %s\n\n", info);
  info = "\nChris Johnson\n12/01/1987\nwork 000-222-0101\ncell 000-222-0189";
  printf("Unit Test #3 Expected Outcome %s", info);
  info = "\nRobert Hall\n2/27/1949\nwork 000-444-0101\ncell 000-444-0189";
  printf("\n\nUnit Test #4 Expected Outcome %s", info);
  return 0;
}